package com.hieu.controller;

import com.hieu.enums.ReviewStatus;
import com.hieu.payload.request.catalog.ReviewApproveRequest;
import com.hieu.payload.request.catalog.ReviewRejectRequest;
import com.hieu.payload.request.catalog.ReviewSubmitRequest;
import com.hieu.payload.response.ApiResponse;
import com.hieu.payload.response.catalog.ReviewRequestResponse;
import com.hieu.service.ReviewRequestService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/version-1/review-requests")
public class ReviewRequestController {

    private final ReviewRequestService reviewRequestService;

    public ReviewRequestController(ReviewRequestService reviewRequestService) {
        this.reviewRequestService = reviewRequestService;
    }

    // tên client gửi -> property trên ReviewRequest. Không cho sort theo field lạ
    private static final Map<String, String> SORTABLE_FIELDS = Map.of(
            "id", "id",
            "status", "status",
            "submittedBy", "submittedBy",
            "reviewedBy", "reviewedBy"
    );
    private static final int MAX_PAGE_SIZE = 100;

    @PostMapping
    public ResponseEntity<ReviewRequestResponse> submit(
            @Valid @RequestBody ReviewSubmitRequest request) throws Exception {
        return ResponseEntity.status(HttpStatus.CREATED).body(reviewRequestService.submit(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReviewRequestResponse> getById(@PathVariable Long id) throws Exception {
        return ResponseEntity.ok(reviewRequestService.getById(id));
    }

    @GetMapping
    public ResponseEntity<Page<ReviewRequestResponse>> getAll(
            @RequestParam(required = false) ReviewStatus status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDirection) {
        return ResponseEntity.ok(reviewRequestService.getAll(
                status, buildPageable(page, size, sortBy, sortDirection)));
    }

    @GetMapping("/pending")
    public ResponseEntity<Page<ReviewRequestResponse>> getPending(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDirection) {
        return ResponseEntity.ok(reviewRequestService.getPending(
                buildPageable(page, size, sortBy, sortDirection)));
    }

    @GetMapping("/by-chapter/{chapterId}")
    public ResponseEntity<Page<ReviewRequestResponse>> getByChapter(
            @PathVariable Long chapterId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDirection) throws Exception {
        return ResponseEntity.ok(reviewRequestService.getByChapter(
                chapterId, buildPageable(page, size, sortBy, sortDirection)));
    }

    @GetMapping("/by-staff/{staffId}")
    public ResponseEntity<Page<ReviewRequestResponse>> getByStaff(
            @PathVariable Long staffId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDirection) {
        return ResponseEntity.ok(reviewRequestService.getByStaff(
                staffId, buildPageable(page, size, sortBy, sortDirection)));
    }

    @PostMapping("/{id}/approve")
    public ResponseEntity<ReviewRequestResponse> approve(
            @PathVariable Long id,
            @Valid @RequestBody ReviewApproveRequest request) throws Exception {
        return ResponseEntity.ok(reviewRequestService.approve(id, request));
    }

    @PostMapping("/{id}/reject")
    public ResponseEntity<ReviewRequestResponse> reject(
            @PathVariable Long id,
            @Valid @RequestBody ReviewRejectRequest request) throws Exception {
        return ResponseEntity.ok(reviewRequestService.reject(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> cancel(
            @PathVariable Long id,
            @RequestParam Long staffId) throws Exception {
        reviewRequestService.cancel(id, staffId);
        return ResponseEntity.ok(new ApiResponse("Hủy yêu cầu duyệt thành công"));
    }

    private Pageable buildPageable(int page, int size, String sortBy, String sortDirection) {
        page = Math.max(0, page);
        size = Math.max(1, Math.min(size, MAX_PAGE_SIZE));

        String property = SORTABLE_FIELDS.getOrDefault(sortBy, "id");
        Sort.Direction direction = "desc".equalsIgnoreCase(sortDirection)
                ? Sort.Direction.DESC
                : Sort.Direction.ASC;

        return PageRequest.of(page, size, Sort.by(direction, property));
    }
}