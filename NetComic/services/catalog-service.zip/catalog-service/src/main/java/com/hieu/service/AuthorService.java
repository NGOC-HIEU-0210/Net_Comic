package com.hieu.service;

public interface AuthorService {
}
